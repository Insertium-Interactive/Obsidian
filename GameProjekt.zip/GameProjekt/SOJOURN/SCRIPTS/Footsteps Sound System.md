
# Használat:

1. **Rakd rá a karakteredre**
	#### Default Hangok =  Untagged Tag
	![[Pasted image 20241001152121.png]]
2. **Csinálj egy Asset-et**
	 #### Create -> ScriptableObjects -> FootstepSoundManager
	 ![[Pasted image 20241001152634.png]]
3. **Tegyél be minden hangot amire szükséged van**
	 #### Csinálj ezekhez Tag-ket -> pl. Dirt, Rock, Wood
	 ![[Pasted image 20241001152838.png]]