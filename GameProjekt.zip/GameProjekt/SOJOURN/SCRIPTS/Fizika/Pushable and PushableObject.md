
# Használat:

1. **Tedd a PushableObject script-et a Player-re**
2. **Tedd a Pushable script-et azokra a tárgyakra amelyek tolhatók legyenek**
4. **Állítsd be az értékeket**
	#### Előre kitapasztalt értékek:
	 
	 példa:![[Pasted image 20241003121458.png]]