# **Cselekmény és Szöveg**:

### **Prologue**:

#### *Bevezető:*

- Csónakkal / Hajóval érkezés
- Tutorial - Kissebb, egyszerű rejtvények megoldása; szűk környezet; kissé feszült hangulat; nem túl hosszú

#### *Pisztoly:*

- Első fegyver
- Attachment-ek később
#### *Mellékvonal 1:*

- Megfertőződés a masszával - Bejárati puzzle közben történik valami ami majd később bír nagy jelentőséggel - Csehov puskája

#### *Bejárati puzzle:*

- Egy olyan puzzle ami a Prologue-t lezárja - Vissza nem térés pontja

[ Miután a bejárati puzzle megoldódik és megnyílik a táj Aria előtt: ]

> [!info]
> ##### MADMAN:
> 
> *Ah, what a sight to behold. It takes a moment to truly absorb the scene.*
>  
> *As you pause to take it all in, don't forget the way everything fits together: the subtle harmony at play, these delicate threads weaving through each moment, each consequence. This unified scene is a clear reflection of your choices - a grand design that has always been yours to shape.* 
>  
> *Embrace the spectacle, because you’ve earned every bit of this curious road you’ve paved, don't you? After all, who wouldn’t want to revisit a place that feels just like home?*
> 



---
### **Chapter 1 / Alea iacta est:** 

#### *Mellékvonal 1:*
 
- 
---
### **Chapter 2 / Biotic Factor:**

#### *Mellékvonal 2:*

- 

#### *Laboratórium Puzzle:* 

- 
---
### **Chapter 3 / Limiting Factor:**

#### *Krízis pont:*

- **Megoldás:** visszatérő ***Mellékvonal 2*** szál


---
### **Chapter 4 / The Dogma:**

#### *Végső Konfliktus:*

- 

---
### **Chapter 5 / Copernican principle:**




---
### **Ending:**
#### **Ending:**
##### **Ending:**
###### **Ending:**




