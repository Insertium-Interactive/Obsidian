
| Aria Hayes | Madman             | Twitcher           |     |
|:----------:| ------------------ | ------------------ |:---:|
| Főszereplő | Mellékszereplő 1.1 | Mellékszereplő 1.2 |     |

### 1. ARIA HAYES / A Vonakodó Hős (Reluctant Hero)

-  **Kor**: 25-30 év
- **Leírás**: Volt tudós, aki egy balul sikerült kísérlet következményei miatt elkellett hagynia a kutatási helyszínt. Most visszatér, hogy felelősséget vállaljon a múltbeli hibáiért.
- ?Daidalosz párhuzam?

### 2. MADMAN / A bölcs bolond (The Wise Fool)

- **Kor**: 50 - 60 év
- **Leírás**: Rejtélyes nyomokat vagy figyelmeztetéseket ad, amelyek segíthetnek a főszereplőnek megérteni saját magát vagy előre látni a jövőbeli eseményeket. 
- Minden tanácsa értelmetlennek tűnik addig amíg kontextusba nem kerül
- Cinikus
- Fura

### 3. TWITCHER / Csendes szövetséges (Silent Ally)

- **Kor**: ?
- **Leírás**: Feladatok elvégzésével vagy közvetlen beavatkozással segíti a főszereplőt, például veszélyes területeken való átvezetéssel vagy puzzle tárgyak megtalálásában. (Tutorial)
- Neve literális mert folyamatosan remeg
- Állatra emlékeztető forma
